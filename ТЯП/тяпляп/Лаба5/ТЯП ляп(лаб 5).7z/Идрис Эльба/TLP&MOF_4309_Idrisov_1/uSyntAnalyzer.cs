﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace TLP_MOF_4309_Idrisov_1
{
    internal class uSyntAnalyzer
    {
        private String[] strFSource;
        private String[] strFMessage;
        public String[] strPSource { set { strFSource = value; } get { return strFSource; } }
        public String[] strPMessage { set { strFMessage = value; } get { return strFMessage; } }
      
        public CLex Lex = new CLex();

        public void S() // nado
        {
            A();
            if (Lex.enumPToken == TToken.lxmtz)
                C();
            throw new Exception("Конец слова, текст верный. Для продолжения ожидается ;");
        }
        public void C()
        {
            if (Lex.enumPToken == TToken.lxmtz)
            {
                Lex.NextToken();
                B();
                if (Lex.enumPToken == TToken.lxmtz)
                    C();
            }
        }
        public void A()
        {
            B();
            if (Lex.enumPToken == TToken.lxmtz)
                C();
        }
        public void B()
        {
            if (Lex.enumPToken == TToken.lxmNumber)
            {

                Lex.NextToken();
                if (Lex.enumPToken == TToken.lxmComma || Lex.enumPToken == TToken.lxmtz)
                {
                    Lex.NextToken();
                    B();
                }
                else if (Lex.enumPToken == TToken.lxmEmpty)
                {
                    Lex.NextToken();
                }
                else throw new Exception("Ожидалась цифра или конец" + Lex.enumPToken);
            }
            else if (Lex.enumPToken == TToken.lxmIdentifier)
            {
                while (Lex.enumPToken == TToken.lxmIdentifier) Lex.NextToken();
                if (Lex.enumPToken == TToken.lxmdt)
                {
                    Lex.NextToken();
                    if (Lex.enumPToken == TToken.lxmNumber)
                    {
                        Lex.NextToken();
                        
                    }
                    else throw new Exception("Ожидалось 0 или 1");
                }
                else throw new Exception("Ожидалось :");
            }
            else throw new Exception("Ожидался идентификатор");
        }

    }
}
