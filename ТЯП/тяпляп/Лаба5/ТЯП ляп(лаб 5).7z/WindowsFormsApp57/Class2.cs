﻿using System;
using System.Windows.Forms;

namespace WindowsFormsApp57
{
    class uSyntAnalyzer
    {
        private String[] strFSource;
        private String[] strFMessage;
        public String[] strPSource { set { strFSource = value; } get { return strFSource; } }
        public String[] strPMessage { set { strFMessage = value; } get { return strFMessage; } }
        public CLex Lex = new CLex();
        public TreeView derevo;

        public void S()
        {
            TreeNode tek = new TreeNode("S");
            derevo.Nodes.Add(tek);
            if (Lex.enumPToken == TToken.lxmIdentifier)
            {
                tek.Nodes.Add(new TreeNode(Lex.strPLexicalUnit));
                Lex.NextToken();
                if (Lex.enumPToken == TToken.lxmLeftParenth)
                {
                    tek.Nodes.Add(new TreeNode("("));
                    Lex.NextToken();
                    A(tek);
                    if (Lex.enumPToken == TToken.lxmRightParenth)
                    {
                        tek.Nodes.Add(new TreeNode(")"));
                        Lex.NextToken();
                        if (Lex.enumPToken == TToken.twopoints)
                        {
                            tek.Nodes.Add(new TreeNode(":"));
                            Lex.NextToken();
                            if (Lex.enumPToken == TToken.minus)
                            {
                                tek.Nodes.Add(new TreeNode("-"));
                                B(tek);
                            }
                            else throw new Exception("Ожидалась -");
                        }
                        else throw new Exception("Ожидалась :");
                    }
                    else throw new Exception("Ожидалась )");
                }
                else throw new Exception("Ожидалась (");
            }
            else throw new Exception("Неверно. Введите буквы");
            throw new Exception("Конец слова, текст верный. Люблю целую");
        }
        public void A(TreeNode papa)
        {

            TreeNode tek = new TreeNode("A");
            papa.Nodes.Add(tek);
            if (Lex.enumPToken == TToken.lxmNumber)
            {

                tek.Nodes.Add(new TreeNode(Lex.strPLexicalUnit));
                Lex.NextToken();
                if (Lex.enumPToken == TToken.space)
                {
                    tek.Nodes.Add(new TreeNode("_"));
                    A(tek);
                }
                else
                {
                    if (Lex.enumPToken == TToken.lxmNumber)
                    {
                        tek.Nodes.Add(new TreeNode(Lex.strPLexicalUnit));
                        Lex.NextToken();
                    }
                }
            }
            else throw new Exception("Неверно. Введите цифры");
        }
        public void B(TreeNode papa)
        {
            TreeNode tek = new TreeNode("B");
            papa.Nodes.Add(tek);
            Lex.NextToken();
            if (Lex.enumPToken == TToken.lxmIdentifier)
            {

                tek.Nodes.Add(new TreeNode(Lex.strPLexicalUnit));
                Lex.NextToken();
                if (Lex.enumPToken == TToken.lxmComma)
                {
                    tek.Nodes.Add(new TreeNode(","));
                    C(tek);  
                }
                else
                    Lex.NextToken();
            }
            else throw new Exception("Ожидались буквы");
        }
        public void C(TreeNode papa)
        {
            TreeNode tek = new TreeNode("C");
            papa.Nodes.Add(tek);
            Lex.NextToken();
           if (Lex.enumPToken == TToken.lxmIdentifier)
           {
                tek.Nodes.Add(new TreeNode(Lex.strPLexicalUnit));
                Lex.NextToken();
               if (Lex.enumPToken == TToken.lxmComma)
               {
                    tek.Nodes.Add(new TreeNode(","));
                    //Lex.NextToken();
                    C(tek);
               }
           }
            else throw new Exception("Ожидались буквы");
        }
    }

}
