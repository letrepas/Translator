﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp45
{
    public class uSyntAnalyzer
    {
        private String[] strFSource;
        private String[] strFMessage;
        public String[] strPSource { set { strFSource = value; } get { return strFSource; } }
        public String[] strPMessage { set { strFMessage = value; } get { return strFMessage; } }
        public CLex Lex = new CLex();

        public TToken firstToken;
        public TreeView tree;

        public void S()
        {
            TreeNode parent = new TreeNode("S");
            tree.Nodes.Add(parent);

            if (Lex.enumPToken == TToken.lxmLeftParenth) //(A)
            {
                parent.Nodes.Add(new TreeNode(Lex.strPLexicalUnit));
                A(parent);
                if (Lex.enumPToken == TToken.lxmRightParenth)
                {
                    parent.Nodes.Add(new TreeNode(Lex.strPLexicalUnit));
                    throw new Exception("Конец слова, текст верный. [S]");
                }
                else throw new Exception("Ожидалось ) [S]");
            }
            else throw new Exception("Ожидалось ( [S]");
        }
        public void A(TreeNode highParent)
        {
            TreeNode parent = new TreeNode("A");
            highParent.Nodes.Add(parent);

            Lex.NextToken();
            if (Lex.enumPToken == TToken.lxmLeftParenth) //(<2>B)
            {
                parent.Nodes.Add(new TreeNode(Lex.strPLexicalUnit));
                Lex.NextToken();
                if (Lex.enumPToken == TToken.lxmIdentifier || Lex.enumPToken == TToken.lxmNumber)
                {
                    parent.Nodes.Add(new TreeNode(Lex.strPLexicalUnit));
                    firstToken = (TToken)(1 - (int)Lex.enumPToken);
                    B(parent);
                    if (Lex.enumPToken == TToken.lxmRightParenth)
                    {
                        parent.Nodes.Add(new TreeNode(Lex.strPLexicalUnit));
                        Lex.NextToken();
                    }
                    else throw new Exception("Ожидалось ) [A]");
                }
                else throw new Exception("Ожидался идентификатор или число [A]");
            }
            else //<1>
            {
                if(Lex.enumPToken == TToken.lxmIdentifier || Lex.enumPToken == TToken.lxmNumber) 
                {
                    firstToken = Lex.enumPToken;
                    Lex.NextToken();
                }
                else throw new Exception("Ожидался идентификатор или число или ( [A]");
            }
        }
        public void B(TreeNode highParent)
        {
            TreeNode parent = new TreeNode("B"); 
            highParent.Nodes.Add(parent);

            Lex.NextToken();
            if (Lex.enumPToken == TToken.lxmLeftParenth) //(C)
            {
                parent.Nodes.Add(new TreeNode(Lex.strPLexicalUnit));
                Lex.NextToken();
                C(parent);
                if (Lex.enumPToken == TToken.lxmRightParenth)
                {
                    parent.Nodes.Add(new TreeNode(Lex.strPLexicalUnit));
                    Lex.NextToken();
                }
                else throw new Exception("Ожидалось ) [B]");
            }
            else throw new Exception("Ожидалось ( [B]");
        }
        public void C(TreeNode highParent)
        {
            TreeNode parent = new TreeNode("C");
            highParent.Nodes.Add(parent);

            if (Lex.enumPToken == firstToken)
            {
                parent.Nodes.Add(new TreeNode(Lex.strPLexicalUnit));
                D(parent);
            }
            else throw new Exception("Ожидался идентификатор или число [C]");
        }
        public void D(TreeNode highParent)
        {
            TreeNode parent = new TreeNode("D");
            highParent.Nodes.Add(parent);

            Lex.NextToken();
            if (Lex.enumPToken == TToken.lxmComma)
            {
                parent.Nodes.Add(new TreeNode(Lex.strPLexicalUnit));
                Lex.NextToken();
                if (Lex.enumPToken == firstToken)
                {
                    parent.Nodes.Add(new TreeNode(Lex.strPLexicalUnit));
                    D(parent);
                }
                else throw new Exception("Ожидался идентификатор или число [D]");
            }
        }
    }
}

