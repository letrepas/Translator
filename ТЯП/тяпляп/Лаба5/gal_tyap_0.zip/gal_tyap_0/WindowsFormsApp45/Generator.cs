﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp45
{
    public class Generator
    {
        public List<string> ViewTree(TreeView tree, bool edit = true)
        {
            List<string> treeContent = new List<string>();
            foreach(TreeNode node in tree.Nodes)
            {
                treeContent.AddRange(ViewNode(node, edit));
            }
            return treeContent;
        }
        public List<string> ViewNode(TreeNode node, bool edit)
        {
            List<string> nodeContent = new List<string>();
            foreach (TreeNode child in node.Nodes)
            {
                nodeContent.AddRange(ViewNode(child, edit));
            }
            if (edit)
            {
                int value = -1;
                if (int.TryParse(node.Text, out value))
                {
                    int newValue = ConvertToBase10(value);
                    node.Text = newValue.ToString();
                }
            }
            nodeContent.Add(node.Text);
            return nodeContent;
        }

        public int ConvertToBase10(int num)
        {
            int k = 0;
            for (int i = 0; i < num.ToString().Length; i++)
            {
                int r = num.ToString().Length - i;
                int v = num.ToString()[i] == '1' ? 1 : 0;
                k += (int)Math.Pow(2, r - 1) * v;
            }
            return k;
        }

        public void Restruct(RichTextBox box, TreeView tree)
        {
            box.Clear();
            List<string> treeContent = ViewTree(tree, false);
            int depth = 0;
            foreach(string s in treeContent)
            {
                if (s.Length > 0 && !(s[0] == ',' && !(s[0] >= 'A' && s[0] <= 'Z')))
                {
                    for (int i = 0; i < depth; i++)
                    {
                        box.Text += "\t";
                    }
                }
                if (s.Length > 1)
                {
                    box.Text += s;
                }
                else
                {
                    if (s.Length == 1)
                    {
                        if(s[0] == '(')
                        {
                            box.Text += s;
                            box.Text += '\n';
                            depth++;
                        }
                        else if (s[0] == ')')
                        {
                            box.Text += s;
                            box.Text += '\n';
                            depth--;
                        }
                        else if (s[0] == ',')
                        {
                            box.Text += s;
                            box.Text += '\n';
                        }
                        else if(s[0] >= 'A' && s[0] <= 'Z')
                        {
                            
                        }
                        else
                        {
                            box.Text += s;
                        }
                    }
                }
            }
        }
    }
}
