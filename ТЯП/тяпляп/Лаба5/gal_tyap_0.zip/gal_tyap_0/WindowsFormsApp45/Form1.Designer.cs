﻿namespace WindowsFormsApp45
{
    partial class Form1
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnF = new System.Windows.Forms.Button();
            this.tbFMessage = new System.Windows.Forms.TextBox();
            this.tbFSource = new System.Windows.Forms.RichTextBox();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.listBox2 = new System.Windows.Forms.ListBox();
            this.btnFRecord = new System.Windows.Forms.Button();
            this.btnDelete = new System.Windows.Forms.Button();
            this.listBox3 = new System.Windows.Forms.ListBox();
            this.findBtn = new System.Windows.Forms.Button();
            this.ChngBtn = new System.Windows.Forms.Button();
            this.treeView1 = new System.Windows.Forms.TreeView();
            this.genBox = new System.Windows.Forms.RichTextBox();
            this.SuspendLayout();
            // 
            // btnF
            // 
            this.btnF.Location = new System.Drawing.Point(12, 88);
            this.btnF.Name = "btnF";
            this.btnF.Size = new System.Drawing.Size(72, 23);
            this.btnF.TabIndex = 0;
            this.btnF.Text = "Проверить";
            this.btnF.UseVisualStyleBackColor = true;
            this.btnF.Click += new System.EventHandler(this.btnFStart_Click);
            // 
            // tbFMessage
            // 
            this.tbFMessage.Location = new System.Drawing.Point(12, 117);
            this.tbFMessage.Multiline = true;
            this.tbFMessage.Name = "tbFMessage";
            this.tbFMessage.Size = new System.Drawing.Size(321, 81);
            this.tbFMessage.TabIndex = 1;
            // 
            // tbFSource
            // 
            this.tbFSource.Location = new System.Drawing.Point(12, 12);
            this.tbFSource.Name = "tbFSource";
            this.tbFSource.Size = new System.Drawing.Size(321, 70);
            this.tbFSource.TabIndex = 2;
            this.tbFSource.Text = "";
            // 
            // listBox1
            // 
            this.listBox1.FormattingEnabled = true;
            this.listBox1.Location = new System.Drawing.Point(339, 12);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(120, 186);
            this.listBox1.TabIndex = 3;
            this.listBox1.SelectedIndexChanged += new System.EventHandler(this.listBox1_SelectedIndexChanged);
            // 
            // listBox2
            // 
            this.listBox2.FormattingEnabled = true;
            this.listBox2.Location = new System.Drawing.Point(465, 12);
            this.listBox2.Name = "listBox2";
            this.listBox2.Size = new System.Drawing.Size(120, 186);
            this.listBox2.TabIndex = 4;
            this.listBox2.SelectedIndexChanged += new System.EventHandler(this.listBox2_SelectedIndexChanged);
            // 
            // btnFRecord
            // 
            this.btnFRecord.Location = new System.Drawing.Point(86, 88);
            this.btnFRecord.Name = "btnFRecord";
            this.btnFRecord.Size = new System.Drawing.Size(63, 23);
            this.btnFRecord.TabIndex = 6;
            this.btnFRecord.Text = "Записать";
            this.btnFRecord.UseVisualStyleBackColor = true;
            this.btnFRecord.Click += new System.EventHandler(this.btnFRecord_Click);
            // 
            // btnDelete
            // 
            this.btnDelete.Location = new System.Drawing.Point(275, 88);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(58, 23);
            this.btnDelete.TabIndex = 6;
            this.btnDelete.Text = "Удалить";
            this.btnDelete.UseVisualStyleBackColor = true;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // listBox3
            // 
            this.listBox3.FormattingEnabled = true;
            this.listBox3.Location = new System.Drawing.Point(591, 12);
            this.listBox3.Name = "listBox3";
            this.listBox3.Size = new System.Drawing.Size(120, 186);
            this.listBox3.TabIndex = 4;
            this.listBox3.SelectedIndexChanged += new System.EventHandler(this.listBox3_SelectedIndexChanged);
            // 
            // findBtn
            // 
            this.findBtn.Location = new System.Drawing.Point(152, 88);
            this.findBtn.Name = "findBtn";
            this.findBtn.Size = new System.Drawing.Size(47, 23);
            this.findBtn.TabIndex = 0;
            this.findBtn.Text = "Найти";
            this.findBtn.UseVisualStyleBackColor = true;
            this.findBtn.Click += new System.EventHandler(this.findBtn_Click);
            // 
            // ChngBtn
            // 
            this.ChngBtn.Location = new System.Drawing.Point(203, 88);
            this.ChngBtn.Name = "ChngBtn";
            this.ChngBtn.Size = new System.Drawing.Size(69, 23);
            this.ChngBtn.TabIndex = 0;
            this.ChngBtn.Text = "Изменить";
            this.ChngBtn.UseVisualStyleBackColor = true;
            this.ChngBtn.Click += new System.EventHandler(this.ChngBtn_Click);
            // 
            // treeView1
            // 
            this.treeView1.Location = new System.Drawing.Point(339, 204);
            this.treeView1.Name = "treeView1";
            this.treeView1.Size = new System.Drawing.Size(372, 313);
            this.treeView1.TabIndex = 7;
            // 
            // genBox
            // 
            this.genBox.Location = new System.Drawing.Point(12, 204);
            this.genBox.Name = "genBox";
            this.genBox.Size = new System.Drawing.Size(321, 313);
            this.genBox.TabIndex = 2;
            this.genBox.Text = "";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(717, 529);
            this.Controls.Add(this.treeView1);
            this.Controls.Add(this.btnDelete);
            this.Controls.Add(this.btnFRecord);
            this.Controls.Add(this.listBox3);
            this.Controls.Add(this.listBox2);
            this.Controls.Add(this.listBox1);
            this.Controls.Add(this.genBox);
            this.Controls.Add(this.tbFSource);
            this.Controls.Add(this.tbFMessage);
            this.Controls.Add(this.ChngBtn);
            this.Controls.Add(this.findBtn);
            this.Controls.Add(this.btnF);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnF;
        private System.Windows.Forms.TextBox tbFMessage;
        private System.Windows.Forms.RichTextBox tbFSource;
        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.ListBox listBox2;
        private System.Windows.Forms.Button btnFRecord;
        private System.Windows.Forms.Button btnDelete;
        private System.Windows.Forms.ListBox listBox3;
        private System.Windows.Forms.Button findBtn;
        private System.Windows.Forms.Button ChngBtn;
        private System.Windows.Forms.TreeView treeView1;
        private System.Windows.Forms.RichTextBox genBox;
    }
}

