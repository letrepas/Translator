﻿using System;
using System.Collections.Generic;

namespace WindowsFormsApp4
{
    public class MyHashFunction
    {
        public int HashFunction(string word)
        {
            int hashValue = 0;
            foreach (char c in word)
            {
                hashValue += (int)c;
            }
            return hashValue;
        }

        public void AddWord(Dictionary<int, List<string>> hashTable, string word)
        {
            int hashValue = HashFunction(word);

            if (!hashTable.ContainsKey(hashValue))
            {
                hashTable[hashValue] = new List<string>();
            }
            else
            {
                if (hashTable[hashValue].Contains(word))
                {
                    Console.WriteLine("Слово уже существует: " + word);
                    return;
                }
            }
            hashTable[hashValue].Add(word);
        }
        public int SearchWord(Dictionary<int, List<string>> hashTable, string word)
        {
            int hashValue = HashFunction(word);

            if (hashTable.ContainsKey(hashValue))
            {
                return 1;
            }
            else
            {
                return 0;
            }
        }
        public bool RemoveWord(Dictionary<int, List<string>> hashTable, string word)
        {
            int hashValue = HashFunction(word);

            if (hashTable.ContainsKey(hashValue))
            {
                List<string> words = hashTable[hashValue];
                if (words.Contains(word))
                {
                    words.Remove(word);
                    if (words.Count == 0)
                    {
                        hashTable.Remove(hashValue);
                    }
                    return true;
                }
            }

            return false;
        }
    }
}
