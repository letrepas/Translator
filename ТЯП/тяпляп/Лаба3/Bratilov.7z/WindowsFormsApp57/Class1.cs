﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WindowsFormsApp57
{
    public enum TState { Start, Continue, Finish }; //тип состояния
    public enum TCharType { Letter, Digit, EndRow, EndText, Space, ReservedSymbol }; // тип символа
    public enum TToken { lxmIdentifier, lxmNumber, lxmUnknown, lxmEmpty, lxmLeftParenth, lxmRightParenth, lxmIs, lxmDot, lxmComma };
    public class CLex  //класс лексический анализатор
    {
        private String[] strFSource;  // указатель на массив строк
        private String[] strFMessage;  // указатель на массив строк
        public TCharType enumFSelectionCharType;
        public char chrFSelection;
        private TState enumFState;
        private int intFSourceRowSelection;
        private int intFSourceColSelection;
        private String strFLexicalUnit;
        private TToken enumFToken;
        public String[] strPSource { set { strFSource = value; } get { return strFSource; } }
        public String[] strPMessage { set { strFMessage = value; } get { return strFMessage; } }
        public TState enumPState { set { enumFState = value; } get { return enumFState; } }
        public String strPLexicalUnit { set { strFLexicalUnit = value; } get { return strFLexicalUnit; } }
        public TToken enumPToken { set { enumFToken = value; } get { return enumFToken; } }
        public int intPSourceRowSelection { get { return intFSourceRowSelection; } set { intFSourceRowSelection = value; } }
        public int intPSourceColSelection { get { return intFSourceColSelection; } set { intFSourceColSelection = value; } }
        public CLex()
        {
        }
        public void GetSymbol() //метод класса лексический анализатор
        {
            intFSourceColSelection++; // продвигаем номер колонки
            if (intFSourceColSelection > strFSource[intFSourceRowSelection].Length - 1)
            {
                intFSourceRowSelection++;
                if (intFSourceRowSelection <= strFSource.Length - 1)
                {
                    intFSourceColSelection = -1;
                    chrFSelection = '\0';
                    enumFSelectionCharType = TCharType.EndRow;
                    enumFState = TState.Continue;
                }
                else
                {
                    chrFSelection = '\0';
                    enumFSelectionCharType = TCharType.EndText;
                    enumFState = TState.Finish;
                }
            }
            else
            {
                chrFSelection = strFSource[intFSourceRowSelection][intFSourceColSelection]; //классификация прочитанной литеры
                if (chrFSelection == ' ') enumFSelectionCharType = TCharType.Space;
                else if (chrFSelection >= 'a' && chrFSelection <= 'd') enumFSelectionCharType = TCharType.Letter;
                else if (chrFSelection == '0' || chrFSelection == '1') enumFSelectionCharType = TCharType.Digit;
                else if (chrFSelection == '/') enumFSelectionCharType = TCharType.ReservedSymbol;
                else if (chrFSelection == '*') enumFSelectionCharType = TCharType.ReservedSymbol;

                else if (chrFSelection == '(' || chrFSelection == ')' || chrFSelection == ':' || chrFSelection == '-' || chrFSelection == ',' || chrFSelection == '.' || chrFSelection == '[' || chrFSelection == ']' || chrFSelection == '$' || chrFSelection == '!' || chrFSelection == ';') enumFSelectionCharType = TCharType.ReservedSymbol;
                else throw new System.Exception("Cимвол вне алфавита");
                enumFState = TState.Continue;
            }
        }
        private void TakeSymbol()
        {
            char[] c = { chrFSelection };
            String s = new string(c);
            strFLexicalUnit += s;
            GetSymbol();
        }
        public void NextToken()
        {
            strFLexicalUnit = "";
            if (enumFState == TState.Start)
            {
                intFSourceRowSelection = 0;
                intFSourceColSelection = -1;
                GetSymbol();
            }
            while (enumFSelectionCharType == TCharType.Space || enumFSelectionCharType == TCharType.EndRow)
            {
                GetSymbol();
            }

            if (chrFSelection == '/')
            {
                GetSymbol();
                if (chrFSelection == '/')
                    while (enumFSelectionCharType != TCharType.EndRow)
                    {
                        GetSymbol();
                    }
                GetSymbol();
            }
            switch (enumFSelectionCharType)
            {
                case TCharType.Letter:
                    {
                        //              a     b       c      d
                        //   AFin   | AFin | BFin | CFin | DFin |
                        //   BFin   |      |BFin  | CFin | DFin |
                        //   CFin   |      |      | CFin | DFin |
                        //   DFin   |      |      |      | DFin |
                        AFin:
                        {
                            if (chrFSelection == 'a')
                            {
                                TakeSymbol();
                                goto AFin;
                            }
                            else if (chrFSelection == 'b')
                            {
                                TakeSymbol();
                                goto BFin;
                            }
                            else if (chrFSelection == 'c')
                            {
                                TakeSymbol();
                                goto CFin;
                            }
                            else if (chrFSelection == 'd')
                            {
                                TakeSymbol();
                                goto DFin;
                            }
                            else
                            {
                                enumFToken = TToken.lxmIdentifier;
                                return;
                            }
                        }
                        BFin:
                        {
                            if (chrFSelection == 'a')
                            {
                                throw new Exception("Ожидался b или c или d");
                            }
                            if (chrFSelection == 'b')
                            {
                                TakeSymbol();
                                goto BFin;
                            }
                            else if (chrFSelection == 'c')
                            {
                                TakeSymbol();
                                goto CFin;
                            }
                            else if (chrFSelection == 'd')
                            {
                                TakeSymbol();
                                goto DFin;
                            }
                            else
                            {
                                enumFToken = TToken.lxmIdentifier;
                                return;
                            }
                        }
                        CFin:
                        {
                            if (chrFSelection == 'a')
                            {
                                throw new Exception("Ожидался c или d");
                            }
                            else if (chrFSelection == 'b')
                            {
                                throw new Exception("Ожидался c или d");
                            }
                            if (chrFSelection == 'c')
                            {
                                TakeSymbol();
                                goto CFin;
                            }
                            else if (chrFSelection == 'd')
                            {
                                TakeSymbol();
                                goto DFin;
                            }
                            else
                            {
                                enumFToken = TToken.lxmIdentifier;
                                return;
                            }
                        }
                        DFin:
                        {
                            if (chrFSelection == 'a')
                            {
                                throw new Exception("Ожидался d");
                            }
                            else if (chrFSelection == 'b')
                            {
                                throw new Exception("Ожидался d");
                            }
                            else if (chrFSelection == 'c')
                            {
                                throw new Exception("Ожидался d");
                            }
                            if (chrFSelection == 'd')
                            {
                                TakeSymbol();
                                goto DFin;
                            }
                            else
                            {
                                enumFToken = TToken.lxmIdentifier;
                                return;
                            }
                        }
                    }
                    if (chrFSelection == '/')
                    {
                        GetSymbol();
                        if (chrFSelection == '/')
                            while (enumFSelectionCharType != TCharType.EndRow)
                            {
                                GetSymbol();
                            }
                        GetSymbol();
                    }
                case TCharType.Digit:
                    {
                        //              0      1  
                        //    A     |  BD  |      |
                        //    BD    |  CE  |      |
                        //    CE    |  A   | FFin |
                        //    FFin  |  G   |      |
                        //    G     |      |  H   |
                        //    H     | FFin |      |
                        

                        A:
                        if (chrFSelection == '0')
                        {
                            TakeSymbol();
                            goto BD;
                        }
                        else throw new Exception("Ожидался 0");

                        BD:
                        if (chrFSelection == '0')
                        {
                            TakeSymbol();
                            goto CE;
                        }
                        else throw new Exception("Ожидался 0");

                        CE:
                        if (chrFSelection == '0')
                        {
                            TakeSymbol();
                            goto A;
                        }
                        if (chrFSelection == '1')
                        {
                            TakeSymbol();
                            goto FFin;
                        }
                        else throw new Exception("Ожидался 0 или 1");

                        FFin:
                        if (chrFSelection == '0')
                        {
                            TakeSymbol();
                            goto G;
                        }
                        else if (enumFSelectionCharType != TCharType.Digit) { enumFToken = TToken.lxmNumber; return; }
                        else throw new Exception("Ожидался 0");

                        G:
                        if (chrFSelection == '1')
                        {
                            TakeSymbol();
                            goto H;
                        }
                        else throw new Exception("Ожидалась 1");

                        H:
                        if (chrFSelection == '0')
                        {
                            TakeSymbol();
                            goto FFin;
                        }
                        else throw new Exception("Ожидалась 1");

                    }
                case TCharType.ReservedSymbol:
                    {
                        if (chrFSelection == '/')
                        {
                            GetSymbol();
                            if (chrFSelection == '/')
                            {
                                while (enumFSelectionCharType != TCharType.EndRow)
                                    GetSymbol();
                            }
                            GetSymbol();
                        }
                        if (chrFSelection == '(')
                        {
                            enumFToken = TToken.lxmLeftParenth;
                            GetSymbol();
                            return;
                        }
                        if (chrFSelection == ')')
                        {
                            enumFToken = TToken.lxmRightParenth;
                            GetSymbol();
                            return;
                        }
                        break;
                    }
                case TCharType.EndText:
                    {
                        enumFToken = TToken.lxmEmpty;
                        break;
                    }
            }
        }
    }
}

        
    


