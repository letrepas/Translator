﻿using System;
using System.Collections.Generic;
using System.Text;
using nsLex;

namespace nsLex
{
    class uSyntAnalyzer
    {
        private String[] strFSource;
        private String[] strFMessage;
        public String[] strPSource { set { strFSource = value; } get { return strFSource; } }
        public String[] strPMessage { set { strFMessage = value; } get { return strFMessage; } }
        public CLex Lex = new CLex();

        public void S()
        {
            A();
            if (Lex.enumPToken == TToken.lxmddt)
            {
                B();
            }
            else throw new Exception("Ожидалось :");
                throw new Exception("Конец слова, текст верный. Для продолжения ожидается ;");
        }
        public void A()
        {
            if (Lex.enumPToken == TToken.lxmIdentifier)
            {
                Lex.NextToken();
            }
            else throw new Exception("Ожидался идентификатор");
        }
        public void B()
        {
            C();
            Lex.NextToken();
            if (Lex.enumPToken == TToken.lxmdtcomma)
            {       
                E();
            }
        }
        public void E()
        {        
            if (Lex.enumPToken == TToken.lxmdtcomma)
            {
                C();
                Lex.NextToken();
                if (Lex.enumPToken == TToken.lxmdtcomma)
                {
                    E();
                }
            }
        }
        public void C()
        {
            D();
            Lex.NextToken();
            if (Lex.enumPToken == TToken.lxmComma)
            {
                F();
            }
        }
        public void F()
        {
            if (Lex.enumPToken == TToken.lxmComma)
            {
                D();
                Lex.NextToken();
                if (Lex.enumPToken == TToken.lxmComma)
                {
                    F();
                }
            }
        }
        public void D()
        {
            Lex.NextToken();
            if (Lex.enumPToken == TToken.lxmNumber || Lex.enumPToken == TToken.lxmIdentifier)
            {
                Lex.NextToken();
            }
            else throw new Exception("Ожидался идентификатор или число");
        }
    }
}

