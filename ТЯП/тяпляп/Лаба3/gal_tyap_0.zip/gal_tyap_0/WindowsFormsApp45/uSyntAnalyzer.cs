﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApp45
{
    public class uSyntAnalyzer
    {
        private String[] strFSource;
        private String[] strFMessage;
        public String[] strPSource { set { strFSource = value; } get { return strFSource; } }
        public String[] strPMessage { set { strFMessage = value; } get { return strFMessage; } }
        public CLex Lex = new CLex();

        public TToken firstToken;

        public void S()
        {
            if (Lex.enumPToken == TToken.lxmLeftParenth) //(A)
            {
                A();
                if (Lex.enumPToken == TToken.lxmRightParenth)
                {
                    throw new Exception("Конец слова, текст верный.");
                }
                else throw new Exception("Ожидалось )");
            }
            else throw new Exception("Ожидалось (");
        }
        public void A()
        {
            if (Lex.enumPToken == TToken.lxmLeftParenth) //(<2>B)
            {
                Lex.NextToken();
                if (Lex.enumPToken == TToken.lxmIdentifier || Lex.enumPToken == TToken.lxmNumber)
                {
                    firstToken = (TToken)(1 - (int)Lex.enumPToken);
                    B();
                    if (Lex.enumPToken == TToken.lxmRightParenth)
                    {
                        Lex.NextToken();
                    }
                    else throw new Exception("Ожидалось )");
                }
                else throw new Exception("Ожидался идентификатор или число");
            }
            else //<1>
            {
                if(Lex.enumPToken == TToken.lxmIdentifier || Lex.enumPToken == TToken.lxmNumber) 
                {
                    firstToken = Lex.enumPToken;
                }
                else throw new Exception("Ожидался идентификатор или число или (");
            }
        }
        public void B()
        {
            if (Lex.enumPToken == TToken.lxmLeftParenth) //(C)
            {
                Lex.NextToken();
                C();
                if (Lex.enumPToken == TToken.lxmRightParenth)
                {
                    Lex.NextToken();
                }
                else throw new Exception("Ожидалось )");
            }
            else throw new Exception("Ожидалось (");
        }
        public void C()
        {
            if(Lex.enumPToken == firstToken)
            {
                Lex.NextToken();
                D(); 
            }
            else throw new Exception("Ожидался идентификатор или число");
        }
        public void D()
        {
            if (Lex.enumPToken == TToken.lxmComma)
            {
                Lex.NextToken();
                if (Lex.enumPToken == firstToken)
                {
                    D();
                }
            }
        }
    }
}

