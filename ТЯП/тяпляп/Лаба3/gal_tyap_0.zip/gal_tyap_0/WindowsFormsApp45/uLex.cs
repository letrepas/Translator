﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApp45
{
    public enum TState { Start, Continue, Finish }; //тип состояния
    public enum TCharType { Letter, Digit, EndRow, EndText, Space, ReservedSymbol }; // тип символа
    public enum TToken { lxmIdentifier, lxmNumber, lxmUnknown, lxmEmpty, lxmLeftParenth, lxmRightParenth, lxmIs, lxmDot, lxmComma, lxmDollar, lxmMinus, lxmPlus, lxmExclamation, lxmQuestion,
        lxmAnd, lxmLeftParenthSqr, lxmRightParenthSqr, lxmtz, lxmDD };
    public class CLex  //класс лексический анализатор
    {
        private String[] strFSource;  // указатель на массив строк
        private String[] strFMessage;  // указатель на массив строк
        public TCharType enumFSelectionCharType;
        public char chrFSelection;
        private TState enumFState;
        private int intFSourceRowSelection;
        private int intFSourceColSelection;
        private String strFLexicalUnit;
        private TToken enumFToken;
        public String[] strPSource { set { strFSource = value; } get { return strFSource; } }
        public String[] strPMessage { set { strFMessage = value; } get { return strFMessage; } }
        public TState enumPState { set { enumFState = value; } get { return enumFState; } }
        public String strPLexicalUnit { set { strFLexicalUnit = value; } get { return strFLexicalUnit; } }
        public TToken enumPToken { set { enumFToken = value; } get { return enumFToken; } }
        public int intPSourceRowSelection { get { return intFSourceRowSelection; } set { intFSourceRowSelection = value; } }
        public int intPSourceColSelection { get { return intFSourceColSelection; } set { intFSourceColSelection = value; } }

        public CLex()
        {
        }
        public void GetSymbol() //метод класса лексический анализатор
        {
            if (intFSourceColSelection > strFSource[intFSourceRowSelection].Length - 1)
            {
                intFSourceRowSelection++;
                if (intFSourceRowSelection <= strFSource.Length - 1)
                {
                    intFSourceColSelection = -1;
                    chrFSelection = '\0';
                    enumFSelectionCharType = TCharType.EndRow;
                    enumFState = TState.Continue;
                }
                else
                {
                    chrFSelection = '\0';
                    enumFSelectionCharType = TCharType.EndText;
                    enumFState = TState.Finish;

                }
            }
            else
            {
                char[] reservedSymbols = new char[] { '(', ')', '[', ']', '.', ',', '!', '?', '$', '&', '-', '+', ';', ':' };

                chrFSelection = strFSource[intFSourceRowSelection][intFSourceColSelection]; //классификация прочитанной литеры
                if (chrFSelection == ' ') enumFSelectionCharType = TCharType.Space;
                else if (chrFSelection >= 'a' && chrFSelection <= 'd') enumFSelectionCharType = TCharType.Letter;
                else if (chrFSelection == '0' || chrFSelection == '1') enumFSelectionCharType = TCharType.Digit;
                else if (chrFSelection == '/') enumFSelectionCharType = TCharType.ReservedSymbol;
                else if (chrFSelection == '*') enumFSelectionCharType = TCharType.ReservedSymbol;

                else if (reservedSymbols.Contains(chrFSelection)) enumFSelectionCharType = TCharType.ReservedSymbol;
                else throw new System.Exception("Cимвол вне алфавита");
                enumFState = TState.Continue;
            }
            intFSourceColSelection++; // продвигаем номер колонки
        }

        private void TakeSymbol()
        {
            char[] c = { chrFSelection };
            String s = new string(c);
            strPLexicalUnit += s;
            GetSymbol();
        }
        public void NextToken()
        {
            strPLexicalUnit = "";
            if (enumFState == TState.Start)
            {
                intFSourceRowSelection = 0;
                intFSourceColSelection = -1;
                GetSymbol();
            }

            while (enumFSelectionCharType == TCharType.Space || enumFSelectionCharType == TCharType.EndRow)
            {
                GetSymbol();
            }

            if (chrFSelection == '/')
            {
                GetSymbol();
                if (chrFSelection == '/')
                    while (enumFSelectionCharType != TCharType.EndRow)
                    {
                        GetSymbol();
                    }
                GetSymbol();
            }

            switch (enumFSelectionCharType)
            {
                case TCharType.Letter:
                    {
                        //          a       b       c       d   
                        //  A   |   B   |       |       |       |
                        //  B   |       |       | CFin  |       |
                        // CFin | CFin  | CFin  | CFin  | CFin  |
                        A:
                        {
                            if (chrFSelection == 'a')
                            {
                                TakeSymbol();
                                goto B;
                            }
                            else throw new Exception("Слово должно начинаться с 'ac'");
                        }
                        B:
                        {

                            if (chrFSelection == 'c')
                            {
                                TakeSymbol();
                                goto CFin;
                            }
                            else throw new Exception("Слово должно начинаться с 'ac'");
                        }
                        CFin:
                        {
                            if (chrFSelection == 'a' || chrFSelection == 'b' || chrFSelection == 'c' || chrFSelection == 'd')
                            {
                                TakeSymbol();
                                goto CFin;
                            }
                            else
                            {
                                enumFToken = TToken.lxmIdentifier;
                                return;
                            }
                        }
                    }
                    if (chrFSelection == '/')
                    {
                        GetSymbol();
                        if (chrFSelection == '/')
                            while (enumFSelectionCharType != TCharType.EndRow)
                            {
                                GetSymbol();
                            }
                        GetSymbol();
                    }
                case TCharType.Digit:
                    {
                        //           0     1  
                        //    A   |  B  |  D  |
                        //    B   |  C  |     |
                        //    C   |  A  |     |
                        //    D   |  E  |     |
                        //    E   |FFin |     |
                        //   FFin |  G  |     |
                        //    G   |     |  H  |
                        //    H   |FFin |     |

                        A:
                        {
                            if (chrFSelection == '0')
                            {
                                TakeSymbol();
                                goto B;
                            }
                            else if (chrFSelection == '1')
                            {
                                TakeSymbol();
                                goto D;
                            }
                            else throw new Exception("Ожидался 0 или 1");
                        }
                        B:
                        {
                            if (chrFSelection == '0')
                            {
                                TakeSymbol();
                                goto C;
                            }
                            else throw new Exception("Ожидался 0");
                        }
                        C:
                        {
                            if (chrFSelection == '0')
                            {
                                TakeSymbol();
                                goto A;
                            }
                            else throw new Exception("Ожидался 0");
                        }
                        D:
                        {
                            if (chrFSelection == '0')
                            {
                                TakeSymbol();
                                goto E;
                            }
                            else throw new Exception("Ожидался 0");
                        }
                        E:
                        {
                            if (chrFSelection == '0')
                            {
                                TakeSymbol();
                                goto FFin;
                            }
                            else throw new Exception("Ожидался 0");
                        }
                        FFin:
                        {
                            if (chrFSelection == '0')
                            {
                                TakeSymbol();
                                goto G;
                            }
                            else if (enumFSelectionCharType != TCharType.Digit)
                            {
                                enumFToken = TToken.lxmNumber;
                                return;
                            }
                            else throw new Exception("Ожидался 0");
                        }
                        G:
                        {
                            if (chrFSelection == '1')
                            {
                                TakeSymbol();
                                goto H;
                            }
                            else throw new Exception("Ожидалась 1");
                        }
                        H:
                        {
                            if (chrFSelection == '0')
                            {
                                TakeSymbol();
                                goto FFin;
                            }
                            else throw new Exception("Ожидался 0");
                        }
                    }
                case TCharType.ReservedSymbol:
                    {
                        if (chrFSelection == '/')
                        {
                            GetSymbol();
                            if (chrFSelection == '/')
                            {
                                while (enumFSelectionCharType != TCharType.EndRow)
                                    GetSymbol();
                            }
                            GetSymbol();
                        }
                        if (chrFSelection == '(')
                        {
                            enumFToken = TToken.lxmLeftParenth;
                            GetSymbol();
                            return;
                        }
                        if (chrFSelection == ')')
                        {
                            enumFToken = TToken.lxmRightParenth;
                            GetSymbol();
                            return;
                        }
                        if (chrFSelection == '.')
                        {
                            enumFToken = TToken.lxmDot;
                            GetSymbol();
                            return;
                        }
                        if (chrFSelection == ',')
                        {
                            enumFToken = TToken.lxmComma;
                            GetSymbol();
                            return;
                        }
                        if (chrFSelection == '[')
                        {
                            enumFToken = TToken.lxmLeftParenthSqr;
                            GetSymbol();
                            return;
                        }
                        if (chrFSelection == ']')
                        {
                            enumFToken = TToken.lxmRightParenthSqr;
                            GetSymbol();
                            return;
                        }
                        if (chrFSelection == '!')
                        {
                            enumFToken = TToken.lxmExclamation;
                            GetSymbol();
                            return;
                        }
                        if (chrFSelection == '?')
                        {
                            enumFToken = TToken.lxmQuestion;
                            GetSymbol();
                            return;
                        }
                        if (chrFSelection == '&')
                        {
                            enumFToken = TToken.lxmAnd;
                            GetSymbol();
                            return;
                        }
                        if (chrFSelection == '$')
                        {
                            enumFToken = TToken.lxmDollar;
                            GetSymbol();
                            return;
                        }
                        if (chrFSelection == '+')
                        {
                            enumFToken = TToken.lxmPlus;
                            GetSymbol();
                            return;
                        }
                        if (chrFSelection == '-')
                        {
                            enumFToken = TToken.lxmMinus;
                            GetSymbol();
                            return;
                        }
                        if (chrFSelection == ';')
                        {
                            enumFToken = TToken.lxmtz;
                            GetSymbol();
                            return;
                        }
                        if (chrFSelection == ':')
                        {
                            enumFToken = TToken.lxmDD;
                            GetSymbol();
                            return;
                        }
                        break;
                    }

                case TCharType.EndText:
                    {
                        enumFToken = TToken.lxmEmpty;
                        break;
                    }
            }
        }
    }
}