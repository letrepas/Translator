﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp4
{
    class uSemantAnalyzer
    {
        public int i = 0;
        public string strIndentifier;
        public string strDigital;
        private TreeView tree;
        public uSemantAnalyzer()
        {

        }
        public uSemantAnalyzer(TreeView treeView)
        {
            tree = treeView;
            TreeController(tree);
        }
        public void TreeController(TreeView tree)
        {
            foreach (TreeNode node in tree.Nodes)
            {
                TreeController(node);
            }
        }

        public void TreeController(TreeNode node)
        {
            if (node.Text == "B")
            {
                if (node.Nodes.Count == 2)
                {
                    strIndentifier = node.Nodes[0].Nodes[0].Nodes[0].Text.ToString();
                    strDigital = node.Nodes[1].Nodes[1].Nodes[0].Nodes[0].Text.ToString();
                    Check(strIndentifier, strDigital, node);
                }
            }

            foreach (TreeNode childNode in node.Nodes)
            {
                TreeController(childNode);
            }
        }
        private void Check(string ident, string digit, TreeNode node)
        {
            if (ident == "bd" && digit == "001011000")
            {
                tree.SelectedNode = node;
                tree.SelectedNode.BackColor = Color.Red;
                throw new Exception("Условие не выполнено");
            }
        }

    }
}
