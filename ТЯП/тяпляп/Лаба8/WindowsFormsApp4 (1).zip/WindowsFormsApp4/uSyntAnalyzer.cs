﻿using System;
using System.Windows.Forms;

namespace WindowsFormsApp4
{
    class uSyntAnalyzer
    {
        private String[] strFSource;
        private String[] strFMessage;
        public String[] strPSource { set { strFSource = value; } get { return strFSource; } }
        public String[] strPMessage { set { strFMessage = value; } get { return strFMessage; } }
        public CLex Lex = new CLex();
        public TreeView Tree;


        public void S()
        {
            TreeNode Temp = new TreeNode("S");
            Tree.Nodes.Add(Temp);
            A(Temp);
            if (Lex.enumPToken == TToken.lxmddt)
            {
                Temp.Nodes.Add(new TreeNode(":"));
                B(Temp);
            }
            else throw new Exception("Ожидалось :");
            throw new Exception("Конец слова, текст верный. Для продолжения ожидается ;");
        }
        public void A(TreeNode Par)
        {
            TreeNode Temp = new TreeNode("A");
            Par.Nodes.Add(Temp);
            if (Lex.enumPToken == TToken.lxmIdentifier)
            {
                Temp.Nodes.Add(new TreeNode(Lex.strPLexicalUnit));
                Lex.NextToken();
            }
            else throw new Exception("Ожидался идентификатор");
        }
        public void B(TreeNode Par)
        {
            TreeNode Temp = new TreeNode("B");
            Par.Nodes.Add(Temp);
            C(Temp);
            //Lex.NextToken();
            if (Lex.enumPToken == TToken.lxmdtcomma)
            {
                //Temp.Nodes.Add(new TreeNode(";"));
                E(Temp);
            }
        }
        public void E(TreeNode Par)
        {
            TreeNode Temp = new TreeNode("E");
            Par.Nodes.Add(Temp);
            if (Lex.enumPToken == TToken.lxmdtcomma)
            {
                Temp.Nodes.Add(new TreeNode(";"));
                C(Temp);
                Lex.NextToken();
                if (Lex.enumPToken == TToken.lxmdtcomma)
                {
                    //Temp.Nodes.Add(new TreeNode(";"));
                    E(Temp);
                }

            }
            else throw new Exception("Ожидался ;");
        }
        public void C(TreeNode Par)
        {
            TreeNode Temp = new TreeNode("C");
            Par.Nodes.Add(Temp);
            D(Temp);
            Lex.NextToken();
            if (Lex.enumPToken == TToken.lxmComma)
            {
                //Temp.Nodes.Add(new TreeNode(","));
                F(Temp);
            }

        }
        public void F(TreeNode Par)
        {
            TreeNode Temp = new TreeNode("F");
            Par.Nodes.Add(Temp);
            if (Lex.enumPToken == TToken.lxmComma)
            {
                Temp.Nodes.Add(new TreeNode(","));
                D(Temp);
                Lex.NextToken();
                if (Lex.enumPToken == TToken.lxmComma)
                {
                    //Temp.Nodes.Add(new TreeNode(","));
                    F(Temp);
                }
            }

        }
        public void D(TreeNode Par)
        {
            TreeNode Temp = new TreeNode("D");
            Par.Nodes.Add(Temp);
            Lex.NextToken();
            if (Lex.enumPToken == TToken.lxmNumber || Lex.enumPToken == TToken.lxmIdentifier)
            {
                if (!IsNumberUnique(Lex.strPLexicalUnit) && Lex.enumPToken == TToken.lxmNumber)
                {
                    throw new Exception("Число " + Lex.strPLexicalUnit + " повторилось!");
                }
                else
                {
                    Temp.Nodes.Add(new TreeNode(Lex.strPLexicalUnit));
                    uSemantAnalyzer uSemant = new uSemantAnalyzer(Tree);
                }
            }
            else throw new Exception("Ожидался идентификатор или число");
        }
        private bool IsNumberUnique(string Num)
        {

            foreach (TreeNode node in Tree.Nodes)
            {
                if (!IsNumberUniqueInNode(Num, node))
                {
                    return false;
                }
            }

            return true;
        }

        private bool IsNumberUniqueInNode(string Num, TreeNode node)
        {

            if (node.Text == Num)
            {
                return false;
            }


            foreach (TreeNode child in node.Nodes)
            {
                if (!IsNumberUniqueInNode(Num, child))
                {
                    return false;
                }
            }

            return true;
        }

    }
}