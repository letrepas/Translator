﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp4
{
    internal class Generator
    {
        public List<string> ViewTree(TreeView tree, bool edit = true)
        {
            List<string> treeContent = new List<string>();
            foreach (TreeNode node in tree.Nodes)
            {
                treeContent.AddRange(ViewNode(node, edit));
            }
            return treeContent;
        }
        public List<string> ViewNode(TreeNode node, bool edit)
        {
            List<string> nodeContent = new List<string>();
            foreach (TreeNode child in node.Nodes)
            {
                nodeContent.AddRange(ViewNode(child, edit));
            }
            if (edit)
            {
                int value = -1;
                if (int.TryParse(node.Text, out value))
                {
                    int newValue = ConvertToBase10(value);
                    node.Text = newValue.ToString();
                }
            }
            nodeContent.Add(node.Text);
            return nodeContent;
        }
        public int ConvertToBase10(int num)
        {
            int k = 0;
            for (int i = 0; i < num.ToString().Length; i++)
            {
                int r = num.ToString().Length - i;
                int v = num.ToString()[i] == '1' ? 1 : 0;
                k += (int)Math.Pow(2, r - 1) * v;
            }
            return k;
        }
        public TreeView currentTree;
        public int depth = 0;
        public void Restruct(TreeView box, TreeView tree)
        {
            currentTree = tree;
            tree.Nodes.Clear();
            TreeNode sNode = null;
            foreach (TreeNode node in box.Nodes)
            {
                TreeNode newNode = new TreeNode(node.Text);
                ReNode(null, node, ref newNode);
                tree.Nodes.Add(newNode);
            }
            List<TreeNode> remove = new List<TreeNode>();
            foreach (TreeNode node in tree.Nodes)
            {
                if (node.Text != "S" && sNode != null)
                {
                    remove.Add(node);
                }
            }
            tree.ExpandAll();
        }
        public void ReNode(TreeNode parent, TreeNode node, ref TreeNode newNode)
        {
            bool skipToRoot = false;
            foreach (TreeNode child in node.Nodes)
            {
                TreeNode newn = new TreeNode(child.Text);
                int value = -1;
                if (int.TryParse(newn.Text, out value))
                {
                    int newValue = ConvertToBase10(value);
                    newn.Text = newValue.ToString();
                }
                if (child.FullPath.Contains('('))
                {
                    skipToRoot = true;
                }
                ReNode(newNode, child, ref newn);
            }
            if (parent != null)
            {
                if (currentTree != null && skipToRoot)
                {
                    currentTree.Nodes.Add(newNode);
                }
                else
                {
                    parent.Nodes.Add(newNode);
                }
            }
        }
        public static void RefactorTree(TreeView tree)
        {
            TreeNode nodeTemp = null;
            foreach (TreeNode node in tree.Nodes)
            {
                nodeTemp = RefactorTreeNodes(tree, node);
                if (nodeTemp != null)
                {
                    node.Nodes.Remove(nodeTemp);
                    tree.Nodes.Add(nodeTemp);
                }
            }
        }
        public static TreeNode RefactorTreeNodes(TreeView tree, TreeNode parent)
        {
            TreeNode nodeToMove = null;
            TreeNode nodeTemp = null;
            foreach (TreeNode node in parent.Nodes)
            {
                nodeTemp = RefactorTreeNodes(tree, node);
                
                if (nodeTemp != null)
                {
                    if (parent.Text == "S" && nodeTemp.Text == ":")
                    {
                        nodeToMove = nodeTemp;
                    }
                    else
                        if (parent.Text == "B" && nodeTemp.Text == ";")
                        {
                            nodeToMove = nodeTemp;
                        }
                        else
                            if (parent.Text == "C" && nodeTemp.Text == ",")
                            {
                                nodeToMove = nodeTemp;
                            }
                            else
                            {
                                node.Nodes.Remove(nodeTemp);
                                parent.Nodes.Add(nodeTemp);
                            }
                }
                if (parent.Text == "S" && node.Text == ":")
                {
                    nodeToMove = node;
                }
                if (parent.Text == "E" && node.Text == ";")
                {
                    nodeToMove = node;
                }
                if (parent.Text == "F"  && node.Text == ",")
                {
                    nodeToMove = node;
                }

            }
            return nodeToMove;

            //if (nodeToMove != null)
            //{
            //    parent.Nodes.Remove(nodeToMove);
            //    tree.Nodes.Add(nodeToMove);
            //}
        }
    }
}
