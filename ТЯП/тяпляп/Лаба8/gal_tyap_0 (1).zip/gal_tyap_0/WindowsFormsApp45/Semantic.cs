﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Drawing;
using System.Windows.Forms;


namespace WindowsFormsApp45
{
    public class Semantic
    {
        public int countLetters = 0;
        public int countDigits = 0;
        public string strIndentifier;
        public string strDigital;
        private TreeView tree;
        public Semantic()
        {

        }
        public Semantic(TreeView treeView)
        {
            tree = treeView;
            TreeController(tree);
        }
        public void TreeController(TreeView tree)
        {
            foreach (TreeNode node in tree.Nodes)
            {
                TreeController(node);
            }
            Check();
        }

        public void TreeController(TreeNode node)
        {
            if (node.Text == "A")
            {
                if (node.Nodes.Count > 1)
                {
                    strIndentifier = node.Nodes[1].Text.ToString();
                    CheckLetters(strIndentifier);
                }
            }
            if (node.Text == "C")
            {
                if (node.Nodes.Count > 0)
                {
                    strDigital = node.Nodes[0].Text.ToString();
                    countDigits++;
                }
            }
            if (node.Text == "D")
            {
                if (node.Nodes.Count > 1)
                {
                    strDigital = node.Nodes[1].Text.ToString();
                    countDigits++;
                }
            }

            foreach (TreeNode childNode in node.Nodes)
            {
                TreeController(childNode);
            }
        }

        //Проверка равенства количества согласных в конце идентификатора с количеством дополнительных блоков двоичной записи в конструкциях вида <2>, <2> 
        private void Check()
        {
            if (countDigits != countLetters)
            {
                throw new Exception("Ошибка: число согласных не равно числу элементов");
            }
            else
            {
                throw new Exception("Конец слова, текст верный. [S]");
            }
        }

        private void CheckLetters(string input)
        {
            for (int i = input.Length - 1; i >= 0; --i)
            {
                if (input[i] == 'd' || input[i] == 'c' || input[i] == 'b')
                {
                    countLetters++;
                }
                else
                {
                    break;
                }
            }
        } 
    }
}