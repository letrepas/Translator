﻿using System;

namespace WindowsFormsApp4
{
    class uSyntAnalyzer
    {

        private String[] strFSource;
        private String[] strFMessage;
        public String[] strPSource { set { strFSource = value; } get { return strFSource; } }
        public String[] strPMessage { set { strFMessage = value; } get { return strFMessage; } }
        public CLex Lex = new CLex();

        public void S()
        {
            A();

            if (Lex.enumPToken == TToken.lxmdt)
            {
                Lex.NextToken();
                if (Lex.enumPToken == TToken.lxmMinus)
                {
                    Lex.NextToken();
                    B();
                    if (Lex.enumPToken == TToken.lxmDot)
                    {
                        Lex.NextToken();
                    }
                }
                else throw new Exception("Ожидался минус");
            }
            else throw new Exception("Ожидалось двоеточие");
        }

        public void A()
        {
            if (Lex.enumPToken == TToken.lxmIdentifier)
            {
                Lex.NextToken();
                if (Lex.enumPToken == TToken.lxmLeftParenth)
                {
                    Lex.NextToken();
                    if (Lex.enumPToken == TToken.lxmNumber)
                    {
                        Lex.NextToken();
                        if (Lex.enumPToken == TToken.lxmRightParenth)
                        {
                            Lex.NextToken();
                        }
                        else throw new Exception("Ожидалась )");
                    }
                    else throw new Exception("Ожидался числовой идентификатор");
                }
                else throw new Exception("Ожидалась (");
            }
            else throw new Exception("Ожидался буквенный идентификатор");
        }

        public void B()
        {
            A();
            if (Lex.enumPToken == TToken.lxmComma)
                C();
        }
        public void C()
        {
            if (Lex.enumPToken == TToken.lxmComma)
            {
                Lex.NextToken();
                A();
                if (Lex.enumPToken == TToken.lxmComma)
                    C();
            }
        }
    }
}
