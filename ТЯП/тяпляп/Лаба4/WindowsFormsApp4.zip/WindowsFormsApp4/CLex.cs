﻿using System;

namespace WindowsFormsApp4
{
    public enum TState { Start, Continue, Finish }; //тип состояния
    public enum TCharType { Letter, Digit, EndRow, EndText, Space, ReservedSymbol, Undefined }; // тип символа
    public enum TToken { lxmIdentifier, lxmNumber, lxmUnknown, lxmEmpty, lxmLeftParenth, lxmRightParenth, lxmIs, lxmDot, lxmComma, lxmText, lxmMinus, lxmtz, lxmdt, lxmr, lxmrs, lxmls, lxmtd };
    public class CLex  //класс лексический анализатор
    {
        private String[] strFSource;  // указатель на массив строк
        private String[] strFMessage;  // указатель на массив строк
        private String strFLexicalUnit;
        public char chrFSelection;
        private int intFSourceRowSelection;
        private int intFSourceColSelection = -1;
        public TCharType enumFSelectionCharType;
        private TState enumFState;
        private TToken enumFToken;
        public String[] strPSource { set { strFSource = value; } get { return strFSource; } }
        public String[] strPMessage { set { strFMessage = value; } get { return strFMessage; } }
        public String strPLexicalUnit { set { strFLexicalUnit = value; } get { return strFLexicalUnit; } }
        public TState enumPState { set { enumFState = value; } get { return enumFState; } }
        public TToken enumPToken { set { enumFToken = value; } get { return enumFToken; } }
        public int intPSourceRowSelection { get { return intFSourceRowSelection; } set { intFSourceRowSelection = value; } }
        public int intPSourceColSelection { get { return intFSourceColSelection; } set { intFSourceColSelection = value; } }

        public CLex() { }

        public void GetSymbol(bool check = false) //метод класса лексический анализатор
        {
            intFSourceColSelection++; // продвигаем номер колонки
            if (intFSourceColSelection > strFSource[intFSourceRowSelection].Length - 1)
            {
                intFSourceRowSelection++;
                if (intFSourceRowSelection <= strFSource.Length - 1)
                {
                    intFSourceColSelection = -1;
                    chrFSelection = '\0';
                    enumFSelectionCharType = TCharType.EndRow;
                    enumFState = TState.Continue;
                }
                else
                {
                    chrFSelection = '\0';
                    enumFSelectionCharType = TCharType.EndText;
                    enumFState = TState.Finish;
                }
            }
            else
            {
                chrFSelection = strFSource[intFSourceRowSelection][intFSourceColSelection]; //классификация прочитанной литеры
                if (chrFSelection == ' ') enumFSelectionCharType = TCharType.Space;
                else if (chrFSelection >= 'a' && chrFSelection <= 'd') enumFSelectionCharType = TCharType.Letter;
                else if (chrFSelection == '0' || chrFSelection == '1') enumFSelectionCharType = TCharType.Digit;
                else if (chrFSelection == '-') enumFSelectionCharType = TCharType.ReservedSymbol;
                else if (chrFSelection == ':') enumFSelectionCharType = TCharType.ReservedSymbol;
                else if (chrFSelection == '(' || chrFSelection == ')' || chrFSelection == ',' || chrFSelection == '.' || chrFSelection == '/') enumFSelectionCharType = TCharType.ReservedSymbol;
                else throw new System.Exception("Cимвол вне алфавита");
                enumFState = TState.Continue;
            }
        }
        private void TakeSymbol()
        {
            char[] c = { chrFSelection };
            String s = new string(c);
            strFLexicalUnit += s;
            GetSymbol();
        }
        public void NextToken()
        {
            strFLexicalUnit = "";
            if (enumFState == TState.Start)
            {
                intFSourceRowSelection = 0;
                intFSourceColSelection = -1;
                GetSymbol();
            }

            while (enumFSelectionCharType == TCharType.Space || enumFSelectionCharType == TCharType.EndRow)
            {
                GetSymbol();
            }

            if (chrFSelection == '/')
            {
                GetSymbol(true);
                if (chrFSelection == '/')
                    while (enumFSelectionCharType != TCharType.EndRow)
                    {
                        GetSymbol(true);
                    }
                GetSymbol(true);
            }

            // Вариант 4
            switch (enumFSelectionCharType)
            {
                case TCharType.Letter:
                    {
                    //          a      b    c    d             
                    //   A   | CFin |CFin|CFin|  CFin |
                    //   B   | CFin |    |CFin|  CFin |
                    //  CFin | CFin |CFin|CFin|  CFin |

                    A:
                        {
                            if (chrFSelection == 'a' || chrFSelection == 'b' || chrFSelection == 'c' || chrFSelection == 'd')
                            {
                                TakeSymbol();
                                goto B;
                            }

                            else throw new Exception("Слово не должно начинаться с ab");
                        }
                    B:
                        {
                            if (chrFSelection == 'a' || chrFSelection == 'c' || chrFSelection == 'd')
                            {
                                TakeSymbol();
                                goto CFin;
                            }
                            else throw new Exception("Слово не должно начинаться с ab");
                        }

                    CFin:
                        {
                            if (chrFSelection == 'a' || chrFSelection == 'b' || chrFSelection == 'c' || chrFSelection == 'd')
                            {
                                TakeSymbol();
                                goto CFin;
                            }
                            else
                            {
                                enumFToken = TToken.lxmIdentifier;
                                return;
                            }
                        }
                    }

                case TCharType.Digit:
                    {
                    //           0     1  
                    //    A   |  B  |     |
                    //    B   |  C  |  D  |
                    //    C   |  A  |     |
                    //    D   |FFin |     |
                    //    E   |FFin |     |
                    //    G   |  E  |     |
                    //   FFin |     |  G  |


                    A:
                        if (chrFSelection == '0')
                        {
                            TakeSymbol();
                            goto B;
                        }
                        else throw new Exception("Ожидался 0");

                        B:
                        if (chrFSelection == '0')
                        {
                            TakeSymbol();
                            goto C;
                        }
                        else if (chrFSelection == '1')
                        {
                            TakeSymbol();
                            goto D;
                        }
                        else throw new Exception("Ожидался 0");

                        C:
                        if (chrFSelection == '0')
                        {
                            TakeSymbol();
                            goto A;
                        }
                        else throw new Exception("Ожидался 0");

                        D:
                        if (chrFSelection == '0')
                        {
                            TakeSymbol();
                            goto FFin;
                        }
                        else throw new Exception("Ожидался 0");

                        FFin:
                        if (chrFSelection == '1')
                        {
                            TakeSymbol();
                            goto G;
                        }
                        else if (enumFSelectionCharType != TCharType.Digit) { enumFToken = TToken.lxmNumber; return; }
                        else throw new Exception("Ожидалась 1");

                        G:
                        if (chrFSelection == '0')
                        {
                            TakeSymbol();
                            goto E;
                        }
                        else throw new Exception("Ожидался 0");

                        E:
                        if (chrFSelection == '0')
                        {
                            TakeSymbol();
                            goto FFin;
                        }
                        else if (enumFSelectionCharType != TCharType.Digit) { enumFToken = TToken.lxmNumber; return; }
                        else throw new Exception("Ожидался 0");
                    }

                case TCharType.ReservedSymbol:
                    {
                        if (chrFSelection == '/')
                        {
                            TakeSymbol();
                            if (chrFSelection == '/')
                            {
                                while (enumFSelectionCharType != TCharType.EndRow)
                                    TakeSymbol();
                            }
                            TakeSymbol();
                        }
                        if (chrFSelection == '(')
                        {
                            enumFToken = TToken.lxmLeftParenth;
                            TakeSymbol();
                            return;
                        }
                        if (chrFSelection == ')')
                        {
                            enumFToken = TToken.lxmRightParenth;
                            TakeSymbol();
                            return;
                        }
                        if (chrFSelection == '[')
                        {
                            enumFToken = TToken.lxmIs;
                            TakeSymbol();
                            return;
                        }
                        if (chrFSelection == ']')
                        {
                            enumFToken = TToken.lxmrs;
                            TakeSymbol();
                            return;
                        }
                        if (chrFSelection == ',')
                        {
                            enumFToken = TToken.lxmComma;
                            TakeSymbol();
                            return;
                        }
                        if (chrFSelection == ':')
                        {
                            enumFToken = TToken.lxmdt;
                            TakeSymbol();
                            return;
                        }
                        if (chrFSelection == '-')
                        {
                            enumFToken = TToken.lxmMinus;
                            TakeSymbol();
                            return;
                        }
                        if (chrFSelection == '.')
                        {
                            enumFToken = TToken.lxmDot;
                            TakeSymbol();
                            return;
                        }
                        break;
                    }

                case TCharType.EndText:
                    {
                        enumFToken = TToken.lxmEmpty;
                        break;
                    }
            }
        }
    }
}
