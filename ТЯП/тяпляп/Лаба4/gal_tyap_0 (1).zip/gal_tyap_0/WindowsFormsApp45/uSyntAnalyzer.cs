﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApp45
{
    public class uSyntAnalyzer
    {
        private String[] strFSource;
        private String[] strFMessage;
        public String[] strPSource { set { strFSource = value; } get { return strFSource; } }
        public String[] strPMessage { set { strFMessage = value; } get { return strFMessage; } }
        public CLex Lex = new CLex();

        public TToken firstToken;

        public void S()
        {
            if (Lex.enumPToken == TToken.lxmLeftParenth) //(A)
            {
                A();
                if (Lex.enumPToken == TToken.lxmRightParenth)
                {
                    throw new Exception("Конец слова, текст верный. [S]");
                }
                else throw new Exception("Ожидалось ) [S]");
            }
            else throw new Exception("Ожидалось ( [S]");
        }
        public void A()
        {
            Lex.NextToken();
            if (Lex.enumPToken == TToken.lxmLeftParenth) //(<2>B)
            {
                Lex.NextToken();
                if (Lex.enumPToken == TToken.lxmIdentifier || Lex.enumPToken == TToken.lxmNumber)
                {
                    firstToken = (TToken)(1 - (int)Lex.enumPToken);
                    B();
                    if (Lex.enumPToken == TToken.lxmRightParenth)
                    {
                        Lex.NextToken();
                    }
                    else throw new Exception("Ожидалось ) [A]");
                }
                else throw new Exception("Ожидался идентификатор или число [A]");
            }
            else //<1>
            {
                if(Lex.enumPToken == TToken.lxmIdentifier || Lex.enumPToken == TToken.lxmNumber) 
                {
                    firstToken = Lex.enumPToken;
                    Lex.NextToken();
                }
                else throw new Exception("Ожидался идентификатор или число или ( [A]");
            }
        }
        public void B()
        {
            Lex.NextToken();
            if (Lex.enumPToken == TToken.lxmLeftParenth) //(C)
            {
                Lex.NextToken();
                C();
                if (Lex.enumPToken == TToken.lxmRightParenth)
                {
                    Lex.NextToken();
                }
                else throw new Exception("Ожидалось ) [B]");
            }
            else throw new Exception("Ожидалось ( [B]");
        }
        public void C()
        {
            if(Lex.enumPToken == firstToken)
            {
                D();
            }
            else throw new Exception("Ожидался идентификатор или число [C]");
        }
        public void D()
        {
            Lex.NextToken();
            if (Lex.enumPToken == TToken.lxmComma)
            {
                Lex.NextToken();
                if (Lex.enumPToken == firstToken)
                {
                    D();
                }
                else throw new Exception("Ожидался идентификатор или число [D]");
            }
        }
    }
}

