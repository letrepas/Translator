﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApp57
{
    public partial class Form1 : Form
    {
        Dictionary<int, List<string>> hashTableIdentifier = new Dictionary<int, List<string>>();
        Dictionary<int, List<string>> hashTableDigital = new Dictionary<int, List<string>>();
        Dictionary<int, List<string>> hashTableRezerv = new Dictionary<int, List<string>>();
        public Class3 hashFunction = new Class3();
        public CHashTableList htl = new CHashTableList(2);
        public Form1()
        {
            InitializeComponent();
            tbFSource.AppendText("abc(001):-ab" + "\r\n");
            int n = tbFSource.Lines.Length;
        }
        public void TablesToMemo(object sender, System.EventArgs e)
        {
            List<string> listTable = new List<string>();

            listBox1.Items.Clear();
            listBox2.Items.Clear();
            listBox3.Items.Clear();

            htl.TableToStringList(0, listTable);
            foreach (var entry in hashTableIdentifier)
            {
                listBox1.Items.Add(string.Join(", ", entry.Value));
            }
            listTable.Clear();

            htl.TableToStringList(1, listTable);
            foreach (var entry in hashTableDigital)
            {
                listBox2.Items.Add(string.Join(", ", entry.Value));
            }
            listTable.Clear();
            foreach (var entry in hashTableRezerv)
            {
                listBox3.Items.Add(string.Join(", ", entry.Value));
            }
            listTable.Clear();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            tbFMessage.Clear();
            uSyntAnalyzer Synt = new uSyntAnalyzer();
            Synt.Lex.strPSource = tbFSource.Lines;
            Synt.Lex.strPMessage = tbFMessage.Lines;
            Synt.Lex.enumPState = TState.Start;
            try
            {
                Synt.Lex.NextToken();
                Synt.S();
                throw new Exception("Текст верный");
            }
            catch (Exception exc)
            {
                tbFMessage.Text += exc.Message;
                tbFSource.Select();
                tbFSource.SelectionStart = 0;
                int n = 0;
                for (int i = 0; i < Synt.Lex.intPSourceRowSelection; i++) n += tbFSource.Lines[i].Length + 2;
                n += Synt.Lex.intPSourceColSelection;
                tbFSource.SelectionLength = n;
            }
        }
        private void button1_Click(object sender, EventArgs e)
        {
            CLex Lex = new CLex();
            Lex.strPSource = tbFSource.Lines;
            Lex.strPMessage = tbFMessage.Lines;
            Lex.intPSourceColSelection = 0;
            Lex.intPSourceRowSelection = 0;
            int x = tbFSource.TextLength;
            int y = tbFSource.Lines.Length;
            tbFMessage.Text = "";
            try
            {
                while (Lex.enumPState != TState.Finish)
                {
                    Lex.NextToken();
                    string s1 = "", s = "";
                    switch (Lex.enumPToken)
                    {
                        case TToken.lxmIdentifier:
                            {
                                hashFunction.AddWord(hashTableIdentifier, Lex.strPLexicalUnit);
                                s1 = "id " + Lex.strPLexicalUnit; int b = 0;
                                if (htl.AddLexicalUnit(Lex.strPLexicalUnit, 0, ref b))
                                {
                                    TablesToMemo(this, e);
                                }
                                break;
                            }
                        case TToken.lxmNumber:
                            {
                                hashFunction.AddWord(hashTableDigital, Lex.strPLexicalUnit);
                                s1 = "num " + Lex.strPLexicalUnit; int b = 0;
                                if (htl.AddLexicalUnit(Lex.strPLexicalUnit, 1, ref b))
                                {
                                    TablesToMemo(this, e);
                                }
                                break;
                            }
                        case TToken.lxmLeftParenth:
                            {
                                hashFunction.AddWord(hashTableRezerv, "(");
                                s1 = "rez " + Lex.strPLexicalUnit; int b = 0;
                                if (htl.AddLexicalUnit(Lex.strPLexicalUnit, 1, ref b))
                                {
                                    TablesToMemo(this, e);
                                }
                                break;
                            }
                        case TToken.lxmRightParenth:
                            {
                                hashFunction.AddWord(hashTableRezerv, ")");
                                s1 = "rez " + Lex.strPLexicalUnit; int b = 0;
                                if (htl.AddLexicalUnit(Lex.strPLexicalUnit, 1, ref b))
                                {
                                    TablesToMemo(this, e);
                                }
                                break;
                            }
                        case TToken.twopoints:
                            {
                                hashFunction.AddWord(hashTableRezerv, ":");
                                s1 = "rez " + Lex.strPLexicalUnit; int b = 0;
                                if (htl.AddLexicalUnit(Lex.strPLexicalUnit, 1, ref b))
                                {
                                    TablesToMemo(this, e);
                                }
                                break;
                            }
                        case TToken.minus:
                            {
                                hashFunction.AddWord(hashTableRezerv, "-");
                                s1 = "rez " + Lex.strPLexicalUnit; int b = 0;
                                if (htl.AddLexicalUnit(Lex.strPLexicalUnit, 1, ref b))
                                {
                                    TablesToMemo(this, e);
                                }
                                break;
                            }
                    }
                    String m = "(" + s + "" + s1 + ")";
                    tbFMessage.Text += m;
                }
            }
            catch (Exception exc)
            {
                tbFMessage.Text += exc.Message;
                tbFSource.Select();
                tbFSource.SelectionStart = 0;
                int n = 0;
                for (int i = 0; i < Lex.intPSourceRowSelection; i++) n += tbFSource.Lines[i].Length + 2;
                n += Lex.intPSourceColSelection;
                tbFSource.SelectionLength = n;
            }

        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (hashFunction.SearchWord(hashTableIdentifier, listBox1.SelectedItem.ToString()) == 1)
            {
                MessageBox.Show("Успешно", "Поиск", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                MessageBox.Show("Ошибка", "Поиск", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            hashFunction.AddWord(hashTableIdentifier, textBox1.Text.ToString());
            MessageBox.Show("Успешно", "Добавление", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void button5_Click(object sender, EventArgs e)
        {
            if (hashFunction.RemoveWord(hashTableIdentifier, listBox1.SelectedItem.ToString()))
            {
                MessageBox.Show("Успешно", "Удаление", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                MessageBox.Show("Ошибка", "Удаление", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            if (hashFunction.RemoveWord(hashTableIdentifier, listBox1.SelectedItem.ToString()))
            {
                hashFunction.AddWord(hashTableIdentifier, textBox1.Text.ToString());
                MessageBox.Show("Успешно", "Изменение", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                MessageBox.Show("Ошибка", "Изменение", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void button7_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();
            listBox2.Items.Clear();
            listBox3.Items.Clear();
            foreach (var entry in hashTableIdentifier)
            {
                listBox1.Items.Add(string.Join(", ", entry.Value));
            }
            foreach (var entry in hashTableDigital)
            {
                listBox2.Items.Add(string.Join(", ", entry.Value));
            }
            foreach (var entry in hashTableRezerv)
            {
                listBox3.Items.Add(string.Join(", ", entry.Value));
            }

        }
    }
}
