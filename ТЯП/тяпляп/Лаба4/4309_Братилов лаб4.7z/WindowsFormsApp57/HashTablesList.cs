﻿using System.Collections.Generic;
using System.Windows.Forms;

namespace WindowsFormsApp57
{
    public class CHashTableList
    {
        private List<THashTable> arrFHashTableList = new List<THashTable>();
        private bool boolFIsSaved;
        public bool boolFIsLoaded;
        private byte byteFTablesSize;
        static THeap objFHeap = new THeap();
        //------------------------------------------------------------------------------
        public CHashTableList(byte byteATableCount)
        {
            this.byteFTablesSize = byteATableCount;
            objFHeap = new THeap();
            Resize(arrFHashTableList, byteATableCount);
        }
        //------------------------------------------------------------------------------      
        static void Resize(List<THashTable> list, int size)
        {
            if (size > list.Count)
                while (size > list.Count)
                {
                    list.Add(new THashTable(ref objFHeap));
                }
            else if (size < list.Count)
                while (list.Count - size > 0)
                    list.RemoveAt(list.Count - 1);
        }
        //------------------------------------------------------------------------------
        public bool AddLexicalUnit(string strALexicalUnit, byte byteATable, ref int intALexicalCode)
        {
            if (byteATable >= arrFHashTableList.Count)
            {
                if (MessageBox.Show("Увеличить количество таблиц?", "Запрашиваемый индекс таблицы не существует.", MessageBoxButtons.YesNo) == DialogResult.Yes)
                    Resize(arrFHashTableList, byteATable + 1);
                else
                    return false;
            }
            return arrFHashTableList[byteATable].AddLexicalUnit(strALexicalUnit, byteATable, ref intALexicalCode);
        }
        //------------------------------------------------------------------------------
        public void TableToStringList(byte byteATable, List<string> sList)
        {
            arrFHashTableList[byteATable].GetLexicalUnitList(ref sList);
        }
        //------------------------------------------------------------------------------
    }
}

