﻿using System;

namespace WindowsFormsApp57
{
    class uSyntAnalyzer
    {
        private String[] strFSource;
        private String[] strFMessage;
        public String[] strPSource { set { strFSource = value; } get { return strFSource; } }
        public String[] strPMessage { set { strFMessage = value; } get { return strFMessage; } }
        public CLex Lex = new CLex();
        public void S()
        {
            if (Lex.enumPToken == TToken.lxmIdentifier)
            {
                Lex.NextToken();
                if (Lex.enumPToken == TToken.lxmLeftParenth)
                {
                    Lex.NextToken();
                    A();
                    if (Lex.enumPToken == TToken.lxmRightParenth)
                    {
                        Lex.NextToken();
                        if (Lex.enumPToken == TToken.twopoints)
                        {
                            Lex.NextToken();
                            if (Lex.enumPToken == TToken.minus)
                            {
                                B();
                            }
                            else throw new Exception("Ожидалась -");
                        }
                        else throw new Exception("Ожидалась :");
                    }
                    else throw new Exception("Ожидалась )");
                }
                else throw new Exception("Ожидалась (");
            }
            else throw new Exception("Неверно. Введите буквы");
            throw new Exception("Конец слова, текст верный. Люблю целую");
        }
        public void A()
        {
           
            if (Lex.enumPToken == TToken.lxmNumber)
            {
                Lex.NextToken();
                if (Lex.enumPToken == TToken.space)
                    A();
                else
                {
                    if (Lex.enumPToken == TToken.lxmNumber)
                        Lex.NextToken();
                }
            }
            else throw new Exception("Неверно. Введите цифры");
        }
        public void B()
        {
            Lex.NextToken();
            if (Lex.enumPToken == TToken.lxmIdentifier)
            {
                Lex.NextToken();
                if (Lex.enumPToken == TToken.lxmComma)
                {
                    C();  
                }
                else
                    Lex.NextToken();
            }
            else throw new Exception("Ожидались буквы");
        }
        public void C()
        {
           Lex.NextToken();
           if (Lex.enumPToken == TToken.lxmIdentifier)
           {
               Lex.NextToken();
               if (Lex.enumPToken == TToken.lxmComma)
               {
                   Lex.NextToken();
                    C();
               }
           }
            else throw new Exception("Ожидались буквы");
        }
    }

}
